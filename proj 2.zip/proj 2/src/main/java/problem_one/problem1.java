package problem_one;

public class problem1 {
    //private final double interest;
    //private final int year;
    private double annualInterestRate;
    private int numberOfYears;
    private double amount;


    /* Construct a future value constructor with specified amount, number of years,
     * and annual interest rate
     */

    /** Default constructor
     * @param annualInterestRate
     * @param numberOfYears
     * @param amount
     */

    public problem1(double annualInterestRate, int numberOfYears, double amount) {
        this.annualInterestRate = annualInterestRate;
        this.numberOfYears = numberOfYears;
        this.amount = amount;
    }


    /** Set a new annualInterestRate */
    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = 2.5;
    }

    /** Return numberOfYears */
    public int getNumberOfYears() {
        return numberOfYears;
    }
    /** Set a new numberOfYears */
    public void setNumberOfYears(int numberOfYears) {
        this.numberOfYears = numberOfYears;
    }

    /** Set a amount */
    public void getAmount(double amount) {
        this.amount = amount;
    }


    /** Find monthly payment then the future value */
    public double getfutureValue() {
        double monthlyInterestRate = annualInterestRate / 1200;
        double futurePayment = amount * (Math.pow(1 + monthlyInterestRate, numberOfYears * 12));
        return futurePayment;
    }



}
