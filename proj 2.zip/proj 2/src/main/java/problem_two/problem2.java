package problem_two;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class problem2 extends Pane {
        public final double radius= 20;
        private double x = radius, y = radius;
        private double dx = 1, dy = 1;
        private Circle circle = new Circle(x, y, radius);

        public problem2() {
            circle.setFill(Color.GREEN); // Set ball color
            getChildren().add(circle); // Place a ball into this pane

        }

        protected void moveBall() {
            // Check boundaries
            if (x < radius || x > getWidth() - radius) {
                dx *= -1; // Change ball move direction

            }
            if (y < radius || y > getHeight() - radius) {
                dy *= -1; // Change ball move direction
            }

            // Adjust ball position
            x += dx;
            y += dy;

        }

    public void moveUp() {
        circle.setCenterY(y -= 10); //move up
    }
    public void moveDown()
    {
        circle.setCenterY(y += 10); //move down
    }
    public void moveLeft() {
        circle.setCenterX(x -= 10); //move left
    }
    public void moveRight()
    {
        circle.setCenterX(x += 10); //move right
    }
}