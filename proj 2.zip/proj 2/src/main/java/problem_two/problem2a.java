package problem_two;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.stage.Stage;

public class problem2a extends Application {
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        // Create a ball pane
        problem2 ballPane = new problem2();

        // Increase and decrease animation
        ballPane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.UP) {
                ballPane.moveUp();
            }
            if (e.getCode() == KeyCode.DOWN) {
                ballPane.moveDown();
            }
            if(e.getCode() == KeyCode.LEFT){
                ballPane.moveLeft();
            }
            if(e.getCode() == KeyCode.RIGHT){
                ballPane.moveRight();
            }
        });

        // Create a scene and place it in the stage
        Scene scene = new Scene(ballPane, 250, 150);
        primaryStage.setTitle("Problem 2"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage

        // Must request focus after the primary stage is displayed
        ballPane.requestFocus();
    }

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
        launch();
    }
}